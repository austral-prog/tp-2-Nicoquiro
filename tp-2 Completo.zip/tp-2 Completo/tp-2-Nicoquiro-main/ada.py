def ada():
    first_name = "AdA"
    last_name = "LoVeLAce"

    print(first_name.lower(),last_name.lower())
    print(first_name.title(),last_name.title())
    print(first_name.upper(),last_name.upper())
    print("\t" + first_name.lower(),last_name.lower())





#Objetivos a lograr:
#ada lovelace 
#Ada Lovelace 
#ADA LOVELACE  
# 	ada lovelace