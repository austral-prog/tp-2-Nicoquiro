def earth():
    x = "Bangladesh"
    y = "Barbados"
    
    first = x < y

    second = x > y

    print(f"The result of {x} comes first in the dictionary than {y} is {first}.")
    print(f"The result of {y} comes first in the dictionary than {x} is {second}.")

